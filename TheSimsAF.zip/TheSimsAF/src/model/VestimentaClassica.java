package model;

public class VestimentaClassica extends Vestimenta {

	public VestimentaClassica() {
		super();
		setCamisa("Social Branca");
		setAcessorio("Relógio");
		setSapato("Sapato Social");
	}

}
