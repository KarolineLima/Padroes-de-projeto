package model;

public class VestimentaEsportista extends Vestimenta {

	public VestimentaEsportista() {
		super();
		setCamisa("Camiseta roxa");
		setAcessorio("sem");
		setSapato("tênis");
	}

}
