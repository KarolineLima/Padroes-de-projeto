package model;

public class CabeloClassico extends Cabelo {

	public CabeloClassico() {
		super();
		setTamanho("curto");
		setEstilo("ondulado");
		setCor("castanho");
	}

}
