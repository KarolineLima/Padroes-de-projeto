package model;

public class CabeloEsportista extends Cabelo {

	public CabeloEsportista() {
		super();
		setTamanho("Longo");
		setEstilo("liso");
		setCor("Loiro");
	}

}
