package model;

public class Embalagem extends Preparo{

	public Embalagem() {}

	public void status() {
		System.out.println("Sendo embalado para o entrega...");
	}
	
}
