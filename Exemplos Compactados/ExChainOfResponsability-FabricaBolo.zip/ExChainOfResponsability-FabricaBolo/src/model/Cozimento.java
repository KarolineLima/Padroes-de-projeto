package model;

public class Cozimento extends Preparo{
	
	public Cozimento() {}
	
	public void status() {
		System.out.println("Em produção...");
	}
}
