package model;

public class Entrega extends Preparo{

	public Entrega() {}

	public void status() {
		System.out.println("Entregue ao cliente.");	
	}
	

	
}
