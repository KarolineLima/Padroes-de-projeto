package model;

public class Confeitar extends Preparo{


	public Confeitar() {}

	
	public void status() {
		System.out.println("Sendo confeitado...");	
	}
	
	
}
