package model;

public class Window {
	
	private String recurso = "Window";
	

	public void setRecurso(String recurso) {
		this.recurso = recurso;
	}
	
	public String draw() {
		return recurso ;
	}
	
}
