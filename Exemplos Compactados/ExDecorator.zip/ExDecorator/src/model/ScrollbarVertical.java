package model;

public class ScrollbarVertical extends WindowDecorator{

	public ScrollbarVertical(Window window) {
		super(window);
		super.setRecurso("ScrollbarVertical");
		super.draw();
	}

}
