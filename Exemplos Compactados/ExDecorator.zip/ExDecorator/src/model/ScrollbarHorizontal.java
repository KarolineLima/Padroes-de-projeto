package model;

public class ScrollbarHorizontal extends WindowDecorator {
	
	public ScrollbarHorizontal(Window OneWindow) {
		super(OneWindow);
		super.setRecurso("ScrollbarHorizontal");
		super.draw();
	}
	
}
