package model;

public interface Congresso {
	
	public int totalParticipantes();
	
	public void addParticipante(Participante p);
	
	public int getTotalAssentos();
	
	public void setTotalAssentos(int totalAssentos); 
	
	
}
