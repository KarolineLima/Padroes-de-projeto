
public enum Tipo {
	 normal, lancamento, infantil
}
