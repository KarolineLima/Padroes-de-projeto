package model;

public interface Implementacao {
	
	public String gerarTipo(String titulo);
	
}
