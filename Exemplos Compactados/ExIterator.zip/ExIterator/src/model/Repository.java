package model;

import java.util.Iterator;

public interface Repository {

	public Iterator<String> getIterator();
	
}
